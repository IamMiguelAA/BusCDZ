package eventos;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class EventoTwitter extends AbstractMessageTransformer{
	String status = new String();
	String idtweet = new String();
	String parada = new String();
	
    public EventoTwitter transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
    	EventoTwitter obj=new EventoTwitter();
    	String mensaje=(String)message.getPayload();
    	int indiceid=mensaje.indexOf("id");
    	indiceid=indiceid+4;
    	obj.idtweet="";
    	while(mensaje.charAt(indiceid)!=','){
    		obj.idtweet=obj.idtweet+mensaje.charAt(indiceid);
    		indiceid++;
    	}
    	
    	int indicename=mensaje.indexOf('"'+"screenName"+'"'+':'+'"',mensaje.indexOf("screenName")+10);
    	indicename=indicename+14;
    	obj.status="";
    	while(mensaje.charAt(indicename)!='"'){
    		obj.status=obj.status+mensaje.charAt(indicename);
    		indicename++;
    	}
    	
    	
    	int indiceparada=mensaje.indexOf('"'+"text"+'"'+':'+'"');
    	indiceparada=indiceparada+8;
    	String parada1="";
    	while(mensaje.charAt(indiceparada)!='"'){
    		parada1=parada1+mensaje.charAt(indiceparada);
    		indiceparada++;
    	}
    	indiceparada=parada1.indexOf('#');
    	if(indiceparada!=-1){
    	obj.parada=obj.parada+parada1.charAt(indiceparada+1);
    	obj.parada=obj.parada+parada1.charAt(indiceparada+2);
    	obj.parada=obj.parada+parada1.charAt(indiceparada+3);
    	obj.parada=obj.parada+parada1.charAt(indiceparada+4);
    	}else{
    		obj.parada="-1";
    	}
    	int paradaa=Integer.valueOf(obj.parada);
    	if(((1101>paradaa) || (paradaa>1126)) && (9905!=paradaa) && ((1201>paradaa) || (paradaa>1245)) && ((1301>paradaa) || (paradaa>1317)) && ((1501>paradaa) || (paradaa>1526)) && (1701!=paradaa) && ((1708>paradaa) || (paradaa>1712))){
    		System.out.println("la parada es:"+paradaa);
    		if(paradaa==-1){}else{
    		obj.parada="-2";
    		}
    	}
    	return obj;
    }
    public String status(){
		return status;
    	
    }
    
    public String idtweet(){
		return idtweet;
    }
    
    public String getparada(){
    	System.out.println("Devolviendo parada"+parada);
		return parada;
    	
    }
    public String emoticono(){
		return "😉";
    	
    }
    public String emoticono2(){
		return "😡";
    	
    }
    
    public String emoticono3(){
		return "😌";
    	
    }
    
}
